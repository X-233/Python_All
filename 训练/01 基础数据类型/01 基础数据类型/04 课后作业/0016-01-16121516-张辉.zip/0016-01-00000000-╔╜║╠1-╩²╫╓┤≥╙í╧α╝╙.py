"""
输入两个数字（input）,相加之后打印输出
"""
# 字符串相加
print(input() + input('\n'))

# 整数相加
print(int(input()) + int(input('\n')))
